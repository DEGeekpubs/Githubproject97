package com.sivalabs.jcart.entities;

/**
 * @author Siva
 *
 */
public enum OrderStatus
{
	NEW, IN_PROCESS, COMPLETED, FAILED
}
