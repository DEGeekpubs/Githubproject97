/**
 * 
 */
package com.sivalabs.jcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Siva
 *
 */
@SpringBootApplication
public class JCartCoreApplication
{

	public static void main(String[] args)
	{
		SpringApplication.run(JCartCoreApplication.class, args);
	}

}
